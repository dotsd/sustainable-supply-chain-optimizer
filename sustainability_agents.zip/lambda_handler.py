
import json
import sys
import os

# Add current directory to path
sys.path.append('/var/task')

try:
    from agents import AgentCore
    from integration_adapter import IntegrationAdapter
    AGENTS_AVAILABLE = True
except ImportError as e:
    print(f"Import error: {e}")
    AGENTS_AVAILABLE = False

def handler(event, context):
    """Main Lambda handler for sustainability analysis"""
    
    try:
        print(f"Received event: {json.dumps(event)}")
        
        if not AGENTS_AVAILABLE:
            return {
                'statusCode': 500,
                'body': json.dumps({
                    'error': 'Agents not available',
                    'message': 'Agent modules could not be imported'
                })
            }
        
        # Handle different event types
        if 'Records' in event:
            # S3 trigger
            return handle_s3_event(event)
        elif 'httpMethod' in event:
            # API Gateway
            return handle_api_event(event)
        else:
            # Direct invocation
            return handle_direct_invocation(event)
            
    except Exception as e:
        print(f"Handler error: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': str(e),
                'message': 'Lambda execution failed'
            })
        }

def handle_direct_invocation(event):
    """Handle direct Lambda invocation"""
    
    # Check if it's a test event
    if event.get('test', False):
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Lambda function is working',
                'agents_available': AGENTS_AVAILABLE,
                'event': event
            })
        }
    
    # Handle sustainability analysis
    supply_chain_data = event.get('supply_chain_data')
    if not supply_chain_data:
        return {
            'statusCode': 400,
            'body': json.dumps({
                'error': 'Missing supply_chain_data'
            })
        }
    
    # Run analysis
    agent_core = AgentCore()
    results = agent_core.orchestrate_sustainability_analysis(supply_chain_data)
    
    return {
        'statusCode': 200,
        'body': json.dumps({
            'results': results,
            'message': 'Analysis completed successfully'
        })
    }

def handle_api_event(event):
    """Handle API Gateway event"""
    
    try:
        body = json.loads(event.get('body', '{}'))
        supply_chain_data = body.get('supply_chain_data')
        
        if not supply_chain_data:
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'Missing supply_chain_data'})
            }
        
        agent_core = AgentCore()
        results = agent_core.orchestrate_sustainability_analysis(supply_chain_data)
        
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'results': results,
                'message': 'Analysis completed successfully'
            })
        }
        
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }

def handle_s3_event(event):
    """Handle S3 trigger event"""
    
    results = []
    
    for record in event['Records']:
        bucket = record['s3']['bucket']['name']
        key = record['s3']['object']['key']
        
        print(f"Processing S3 object: s3://{bucket}/{key}")
        
        # Add S3 processing logic here if needed
        results.append({
            'bucket': bucket,
            'key': key,
            'status': 'processed'
        })
    
    return {
        'statusCode': 200,
        'body': json.dumps({
            'message': f'Processed {len(results)} S3 objects',
            'results': results
        })
    }
